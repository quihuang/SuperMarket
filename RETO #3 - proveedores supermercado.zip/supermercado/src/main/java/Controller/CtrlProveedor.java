/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Classes.Proveedor;
import Model.modeloProveedor;
/**
 *
 * @author quihu
 */
public class CtrlProveedor {
    
    private modeloProveedor modeloProveedor;
    
    public CtrlProveedor(){
         modeloProveedor = new modeloProveedor();
    }
    
    public boolean registrarProveedor(Proveedor objectProveedor){
        
        boolean result = modeloProveedor.crear(objectProveedor);
        
        return result;
    }
    
    public Proveedor buscarProveedor(String nit){
        
        Proveedor result = modeloProveedor.obtenerProveedor(nit);
        
        if(result.getNit() == null){
            return null;
        }else{
            return result;
        } 
    }
    
    public boolean actualizar(Proveedor objectProveedor){
        
        boolean result = modeloProveedor.actualizar(objectProveedor);
        
        return result;
    }
    
    public boolean eliminar(String nit){
        
        boolean result = modeloProveedor.elimnar(nit);
        
        return result;
    }
    
}
